

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Area Starts -->
    <?php echo $__env->make('components.about.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- About Area Start -->
    <?php echo $__env->make('components.about.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Feature Area Starts -->
    <?php echo $__env->make('components.home.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Team Member Area Starts -->
    <?php echo $__env->make('components.about.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Social Link Area Starts -->
    <?php echo $__env->make('components.home.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cromium\resources\views/pages/about.blade.php ENDPATH**/ ?>