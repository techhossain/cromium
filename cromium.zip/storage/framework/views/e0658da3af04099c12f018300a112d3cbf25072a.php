<section class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="title">blog page</h2>
                    <a href="#">home</a><span> / blog page</span>
                </div>
            </div>
        </div>
    </section><?php /**PATH C:\xampp\htdocs\cromium\resources\views/components/blog/breadcrumb.blade.php ENDPATH**/ ?>