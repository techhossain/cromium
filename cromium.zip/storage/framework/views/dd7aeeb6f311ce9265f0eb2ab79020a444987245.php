

<?php $__env->startSection('content'); ?>
    <!-- Hero Area Starts -->
    <?php echo $__env->make('components.home.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- About Area Starts -->
    <?php echo $__env->make('components.home.about-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Feature Area Starts -->
    <?php echo $__env->make('components.home.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Experience & Skills Area Starts -->
    <?php echo $__env->make('components.home.skill', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Portfolio Area Starts -->
    <?php echo $__env->make('components.home.portfolio-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Client Area Starts -->
    <?php echo $__env->make('components.home.client-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- CounterUP Area Starts -->
    <?php echo $__env->make('components.home.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Award Area Starts -->
    <?php echo $__env->make('components.home.award', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Social Link Area Starts -->
    <?php echo $__env->make('components.home.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cromium\resources\views/pages/index.blade.php ENDPATH**/ ?>