<section class="client-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2 class="title">our happy client</h2>
                    </div>
                </div>
            </div>
            <div class="client-slider">
                <div class="client-single-slide">
                    <div class="client-image">
                        <img src="/assets/images/client-1.png" alt="client">
                    </div>
                    <div class="client-content">
                        <p>We are Working Bustle Chances are good there’s a cloud software as a service solution on the market today that will serve..</p>
                        <div class="client-content-bottom">
                            <div class="client-author">
                                <span>john doe</span>
                            </div>
                            <div class="client-company">
                                <span>CEO Twitter.</span>
                            </div>
                            <div class="client-rating">
                                <ul>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="client-single-slide">
                    <div class="client-image">
                        <img src="/assets/images/client-2.png" alt="client">
                    </div>
                    <div class="client-content">
                        <p>We are Working Bustle Chances are good there’s a cloud software as a service solution on the market today that will serve..</p>
                        <div class="client-content-bottom">
                            <div class="client-author">
                                <span>andrew dick</span>
                            </div>
                            <div class="client-company">
                                <span>CEO Google</span>
                            </div>
                            <div class="client-rating">
                                <ul>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="client-single-slide">
                    <div class="client-image">
                        <img src="/assets/images/client-1.png" alt="client">
                    </div>
                    <div class="client-content">
                        <p>We are Working Bustle Chances are good there’s a cloud software as a service solution on the market today that will serve..</p>
                        <div class="client-content-bottom">
                            <div class="client-author">
                                <span>Jon Snow</span>
                            </div>
                            <div class="client-company">
                                <span>CEO Facebook</span>
                            </div>
                            <div class="client-rating">
                                <ul>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                    <li><i class="fa fa-star"></i></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php /**PATH C:\xampp\htdocs\cromium\resources\views/components/home/client-area.blade.php ENDPATH**/ ?>