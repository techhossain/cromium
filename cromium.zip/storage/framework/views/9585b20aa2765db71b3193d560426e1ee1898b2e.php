<section class="feature-area padding-top-115 padding-bottom-120">
        <div class="feature-shape item-zooming"></div>
        <div class="feature-hr"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 wow fadeInUp">
                    <div class="feature-top">
                        <div class="section-title">
                            <h2 class="title">cropium The world’s most Powerful tools.</h2>
                        </div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    </div>
                </div>
            </div>
            <!-- Feature Slider Starts -->
            <div class="feature-slider">
                <div class="single-feature-slide">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fa fa-line-chart"></i>
                        </div>
                        <div class="feature-content">
                            <h4 class="title">VS code</h4>
                            <div class="feature-content-para"><p>Strategy experience and analytical combine enable.</p></div>
                            <a href="#" class="feature-btn">read more</a>
                        </div>
                    </div>
                </div>
                <div class="single-feature-slide">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fa fa-cogs"></i>
                        </div>
                        <div class="feature-content">
                            <h4 class="title">react JS</h4>
                            <div class="feature-content-para"><p>Strategy experience and analytical combine enable.</p></div>
                            <a href="#" class="feature-btn">read more</a>
                        </div>
                    </div>
                </div>
                <div class="single-feature-slide">
                    <div class="feature-item active">
                        <div class="feature-icon">
                            <i class="fa fa-pie-chart"></i>
                        </div>
                        <div class="feature-content">
                            <h4 class="title">bootstrap</h4>
                            <div class="feature-content-para"><p>Strategy experience and analytical combine enable.</p></div>
                            <a href="#" class="feature-btn">read more</a>
                        </div>
                    </div>
                </div>
                <div class="single-feature-slide">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fa fa-television"></i>
                        </div>
                        <div class="feature-content">
                            <h4 class="title">laravel</h4>
                            <div class="feature-content-para"><p>Strategy experience and analytical combine enable.</p></div>
                            <a href="#" class="feature-btn">read more</a>
                        </div>
                    </div>
                </div>
                <div class="single-feature-slide">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fa fa-line-chart"></i>
                        </div>
                        <div class="feature-content">
                            <h4 class="title">WordPress</h4>
                            <div class="feature-content-para"><p>Strategy experience and analytical combine enable.</p></div>
                            <a href="#" class="feature-btn">read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH C:\xampp\htdocs\cromium\resources\views/components/home/feature.blade.php ENDPATH**/ ?>