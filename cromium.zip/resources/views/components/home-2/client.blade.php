<section class="client-area-home-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="client-slider-home-2 common-bg-style">
                        <div class="client-single-slide d-md-flex">
                            <div class="client-image">
                                <img src="/assets/images/comment-1.jpg" alt="client">
                            </div>
                            <div class="client-content">
                                <p>We are Working Bustle Chances are good that there’s a cloud software as a service solution on the market today that will serve your core back-office need expertise and genuine passion.</p>
                                <div class="client-content-bottom d-flex align-items-center margin-top-30">
                                    <div class="client-author">
                                        <h4 class="title">john doe</h4>
                                    </div>
                                    <div class="client-company">
                                        <span>CEO Twitter.</span>
                                    </div>
                                    <div class="client-rating">
                                        <ul>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="client-single-slide d-md-flex">
                            <div class="client-image">
                                <img src="/assets/images/comment-3.jpg" alt="client">
                            </div>
                            <div class="client-content">
                                <p>Lorem ipsum dolor sit amet  are good that there’s a cloud software as a service solution on the market today that will serve your core back-office need expertise and genuine passion.</p>
                                <div class="client-content-bottom d-flex align-items-center margin-top-30">
                                    <div class="client-author">
                                        <h4 class="title">devid walter</h4>
                                    </div>
                                    <div class="client-company">
                                        <span>CEO SoftTech IT.</span>
                                    </div>
                                    <div class="client-rating">
                                        <ul>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>