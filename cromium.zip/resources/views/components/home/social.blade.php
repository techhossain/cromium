<section class="social-link padding-top-85 padding-bottom-90">
        <div class="award-shape"><img src="/assets/images/award-shape.png" alt="shape"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2 class="title">let's be follow</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".3s">
                    <div class="social-single-item social-item-1">
                        <span class="social-number">01</span>
                        <div class="social-single-icon">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                        </div>
                        <div class="social-single-content">
                            <h4 class="title">facebook</h4>
                            <span>personal social media</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".4s">
                    <div class="social-single-item social-item-2">
                        <span class="social-number">02</span>
                        <div class="social-single-icon">
                            <a href="#"><i class="fa fa-dribbble"></i></a>
                        </div>
                        <div class="social-single-content">
                            <h4 class="title">dribbble</h4>
                            <span>personal social media</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".5s">
                    <div class="social-single-item social-item-3">
                        <span class="social-number">03</span>
                        <div class="social-single-icon">
                            <a href="#"><i class="fa fa-twitter"></i></a>
                        </div>
                        <div class="social-single-content">
                            <h4 class="title">twitter</h4>
                            <span>personal social media</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".6s">
                    <div class="social-single-item social-item-4">
                        <span class="social-number">04</span>
                        <div class="social-single-icon">
                            <a href="#"><i class="fa fa-behance"></i></a>
                        </div>
                        <div class="social-single-content">
                            <h4 class="title">behance</h4>
                            <span>personal social media</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".7s">
                    <div class="social-single-item social-item-5">
                        <span class="social-number">05</span>
                        <div class="social-single-icon">
                            <a href="#"><i class="fa fa-instagram"></i></a>
                        </div>
                        <div class="social-single-content">
                            <h4 class="title">instagram</h4>
                            <span>personal social media</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay=".8s">
                    <div class="social-single-item social-item-6">
                        <span class="social-number">06</span>
                        <div class="social-single-icon">
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                        </div>
                        <div class="social-single-content">
                            <h4 class="title">linkedin</h4>
                            <span>personal social media</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>