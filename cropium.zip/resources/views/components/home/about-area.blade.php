<section class="about-area padding-top-115 padding-bottom-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 wow fadeInLeft">
                    <div class="about-left">
                        <div class="section-title">
                            <h2 class="title">Any Type of Query & Discussion.</h2>
                        </div>
                        <div class="about-email">
                            <i class="fa fa-envelope-open"></i> <a href="#">johndoe@gmail.com</a>
                        </div>
                        <div class="about-bottom">
                            <div class="about-experience">
                                <span class="experience-years">15</span>
                                <span class="experience-text">Years of <br>Experience</span>
                            </div>
                            <div class="about-client">
                                <span class="all-clients">20+</span>
                                <span class="client-text">saticfied <br>clients</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInRight">
                    <div class="about-right">
                        <div class="section-title">
                            <h2 class="title">You Can't use up creativity the more you use.</h2>
                        </div>
                        <p>consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        <a href="#" class="template-btn about-btn">download CV</a>
                    </div>
                </div>
            </div>
        </div>
    </section>