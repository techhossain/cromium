@extends('components.layout')

@section('content')
    <!-- Breadcrumb Area Starts -->
    @include('components.blog.breadcrumb')


    <!-- Blog Area Starts -->
    @include('components.blog.blog')
    
@endsection