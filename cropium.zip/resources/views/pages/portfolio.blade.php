@extends('components.layout')

@section('content')
    <!-- Breadcrumb Area Starts -->
    @include('components.portfolio.breadcrumb')

    <!-- Portfolio Item Area Starts -->
    @include('components.portfolio.portfolio')
    
@endsection