

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Area Starts -->
    <?php echo $__env->make('components.contact.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Contact Area Starts -->
    <?php echo $__env->make('components.contact.contact-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- Map Area Starts -->
    <?php echo $__env->make('components.contact.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cropium\resources\views/pages/contact.blade.php ENDPATH**/ ?>