<section class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="title">service page</h2>
                    <a href="#">home</a><span> / service page</span>
                </div>
            </div>
        </div>
    </section><?php /**PATH D:\xampp\htdocs\cropium\resources\views/components/service/breadcrumb.blade.php ENDPATH**/ ?>