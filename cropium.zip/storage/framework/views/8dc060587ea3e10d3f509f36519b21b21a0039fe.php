

<?php $__env->startSection('content'); ?>
    <!-- Hero Area Starts -->
    <?php echo $__env->make('components.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- About Area Starts -->
    <?php echo $__env->make('components.about-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Feature Area Starts -->
    <?php echo $__env->make('components.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Experience & Skills Area Starts -->
    <?php echo $__env->make('components.skill', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Portfolio Area Starts -->
    <?php echo $__env->make('components.portfolio-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Client Area Starts -->
    <?php echo $__env->make('components.client-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- CounterUP Area Starts -->
    <?php echo $__env->make('components.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Award Area Starts -->
    <?php echo $__env->make('components.award', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Social Link Area Starts -->
    <?php echo $__env->make('components.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cropium\resources\views/index.blade.php ENDPATH**/ ?>