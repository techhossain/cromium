<section class="social-link-home-2 padding-120">
        <div class="container">
            <div class="social-link-slider">
                <div class="social-single-slide social-item-1">
                    <div class="social-single-icon">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                    </div>
                    <div class="social-single-content">
                        <h4 class="title">facebook</h4>
                        <span>social media</span>
                    </div>
                </div>
                <div class="social-single-slide social-item-2">
                    <div class="social-single-icon">
                        <a href="#"><i class="fa fa-dribbble"></i></a>
                    </div>
                    <div class="social-single-content">
                        <h4 class="title">dribbble</h4>
                        <span>social media</span>
                    </div>
                </div>
                <div class="social-single-slide social-item-3">
                    <div class="social-single-icon">
                        <a href="#"><i class="fa fa-twitter"></i></a>
                    </div>
                    <div class="social-single-content">
                        <h4 class="title">twitter</h4>
                        <span>social media</span>
                    </div>
                </div>
                <div class="social-single-slide social-item-4">
                    <div class="social-single-icon">
                        <a href="#"><i class="fa fa-behance"></i></a>
                    </div>
                    <div class="social-single-content">
                        <h4 class="title">behance</h4>
                        <span>social media</span>
                    </div>
                </div>
                <div class="social-single-slide social-item-5">
                    <div class="social-single-icon">
                        <a href="#"><i class="fa fa-instagram"></i></a>
                    </div>
                    <div class="social-single-content">
                        <h4 class="title">instagram</h4>
                        <span>social media</span>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH D:\xampp\htdocs\cropium\resources\views/components/home-2/social.blade.php ENDPATH**/ ?>