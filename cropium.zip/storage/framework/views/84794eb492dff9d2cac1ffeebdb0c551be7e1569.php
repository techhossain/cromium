<section class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="title">contact page</h2>
                    <a href="#">home</a><span> / contact page</span>
                </div>
            </div>
        </div>
    </section><?php /**PATH D:\xampp\htdocs\cropium\resources\views/components/contact/breadcrumb.blade.php ENDPATH**/ ?>