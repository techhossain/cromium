

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Area Starts -->
    <section class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="title">blog details page</h2>
                    <a href="#">home</a><span> / blog details page</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Blog Details Area Starts -->
    <?php echo $__env->make('components.blog.blog-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cropium\resources\views/pages/blog-details.blade.php ENDPATH**/ ?>