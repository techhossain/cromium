

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Area Starts -->
    <?php echo $__env->make('components.portfolio.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Portfolio Item Area Starts -->
    <?php echo $__env->make('components.portfolio.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cropium\resources\views/pages/portfolio.blade.php ENDPATH**/ ?>