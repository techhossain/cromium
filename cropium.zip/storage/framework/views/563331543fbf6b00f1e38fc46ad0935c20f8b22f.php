

<?php $__env->startSection('content'); ?>
    <!-- Hero Area Starts -->
    <?php echo $__env->make('components.home-2.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- About Area Starts -->
    <?php echo $__env->make('components.home-2.about-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Feature Area Starts -->
    <?php echo $__env->make('components.home-2.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Portfolio Area Starts -->
    <?php echo $__env->make('components.home-2.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Experience & Education Area Starts -->
    <?php echo $__env->make('components.home-2.experience', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Team Area Starts -->
    <?php echo $__env->make('components.home-2.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- Client Area Starts -->
    <?php echo $__env->make('components.home-2.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <!-- Blog Area Starts -->
    <?php echo $__env->make('components.home-2.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Social Link Area Starts -->
    <?php echo $__env->make('components.home-2.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cropium\resources\views/pages/home-2.blade.php ENDPATH**/ ?>