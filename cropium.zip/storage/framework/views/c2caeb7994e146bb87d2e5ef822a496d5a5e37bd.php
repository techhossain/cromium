<section class="award-area padding-top-85">
        <div class="award-shape"><img src="assets/images/award-shape.png" alt="shape"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2 class="title">award acceptance</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay=".3s">
                    <div class="single-award">
                        <div class="award-number">01</div>
                        <img src="assets/images/award.png" alt="">
                        <h4 class="title">udemy certificate</h4>
                        <span>dell institute of technology</span>
                    </div>
                </div>
                <div class="col-lg-4 wow fadeInUp" data-wow-delay=".4s">
                    <div class="single-award">
                        <div class="award-number">02</div>
                        <img src="assets/images/award-2.png" alt="">
                        <h4 class="title">softTech award</h4>
                        <span>totam itaque ratione numquam</span>
                    </div>
                </div>
                <div class="col-lg-4 wow fadeInUp" data-wow-delay=".5s">
                    <div class="single-award">
                        <div class="award-number">03</div>
                        <img src="assets/images/award-3.png" alt="">
                        <h4 class="title">alison certificate</h4>
                        <span>odio nesciunt culpa blanditiis</span>
                    </div>
                </div>
            </div>
        </div>
    </section><?php /**PATH D:\xampp\htdocs\cropium\resources\views/components/home/award.blade.php ENDPATH**/ ?>